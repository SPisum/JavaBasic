public class ArrayDemo {

	public static void main(String[] args){
		
		byte[] arr = new byte[5];
		// arr[2] = 10;
		// ����±�Ϊ4
		// ArrayIndexOutOfBoundsException - �����±�Խ���쳣
		// arr[5] = 7;
		// System.out.println(arr[2]);
		// boolean[] bs = new boolean[4]; 
		// String[] arr = new String[7];
		System.out.println(arr);
		// System.out.println(arr[1]);
		
	}

}