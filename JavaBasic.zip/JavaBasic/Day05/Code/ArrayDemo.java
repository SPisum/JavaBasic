public class ArrayDemo {

	public static void main(String[] args){
		
		// int[] arr = new int[]{5,1,7,0,8,1,3};
		// int[] arr = {3,1,7,3,8,0,4};
		// arr[3] = 15;
		// System.out.println(arr[3]);
		
		int[] arr;
		// arr = new int[5];
		// arr = new int[]{5,1,7,0,8,1,3};
		arr = {3,1,7,3,8,0,4};
	}


}