package cn.tedu.io;

public class Demo02 {
	public static void main(String[] args) {
		
	}
}
