package cn.tedu.newfeature;

import static java.lang.Math.floor;
import static java.lang.Math.ceil;

/**
 * ��̬����
 */
public class Demo03 {
	public static void main(String[] args) {
		//double d1 = Math.floor(3.1415926);
		double d1 = floor(3.1415926);
		System.out.println(d1);
		//double d2 = Math.ceil(3.1415926);
		double d2 = ceil(3.1415926);
		System.out.println(d2);
	}
}
