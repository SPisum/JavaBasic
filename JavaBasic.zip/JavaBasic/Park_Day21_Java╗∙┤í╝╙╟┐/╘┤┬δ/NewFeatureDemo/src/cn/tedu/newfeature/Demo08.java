package cn.tedu.newfeature;

/**
 * ����
 */
public class Demo08 {
	public static void main(String[] args) {
//		List<String> list1 = new ArrayList<String>();
//		List<String> list2 = new ArrayList();
//		List list3 = new ArrayList<String>();
//		List list4 = new ArrayList();
//		List<Object> list5 = new ArrayList<String>();
//		List<String> list6 = new ArrayList<Object>();
		
//		List <? super Teacher> list = null;
//		list = new ArrayList<Object>();
//		list = new ArrayList<Person>();
//		list = new ArrayList<Teacher>();
//		list = new ArrayList<BigTeacher>();
//		list = new ArrayList<Dog>();
//		list = new ArrayList<Cat>();
//		list = new ArrayList<Table>();
	}
	
}
