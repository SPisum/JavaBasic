public class VariableDemo {
	
	public static void main(String[] args){
		
		int i = 6;
		System.out.println(i);
		
	}
	
}
