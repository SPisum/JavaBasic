package cn.tedu.extendsx.a;

public class A {

	protected void m() {
		System.out.println("A m~~~");
	}

}
