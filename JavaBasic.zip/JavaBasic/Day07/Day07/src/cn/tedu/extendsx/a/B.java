package cn.tedu.extendsx.a;

public class B extends A {

//	public static void main(String[] args) {
//
//		B b = new B();
//		b.m();
//
//	}

}
