package cn.tedu.extendsx.b;

import cn.tedu.extendsx.a.A;
//import cn.tedu.extendsx.a.B;

public class D extends A {

	public static void main(String[] args) {

		D d = new D();
		d.m();

		// B b = new B();
		// b.m();

	}

}
