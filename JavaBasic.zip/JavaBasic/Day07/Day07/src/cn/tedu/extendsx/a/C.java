package cn.tedu.extendsx.a;

public class C {

	public static void main(String[] args) {

		A a = new A();
		a.m();

		B b = new B();
		b.m();

	}

}
