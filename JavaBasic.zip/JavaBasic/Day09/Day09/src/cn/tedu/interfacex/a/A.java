package cn.tedu.interfacex.a;

public interface A {

	int i = 10;
}
