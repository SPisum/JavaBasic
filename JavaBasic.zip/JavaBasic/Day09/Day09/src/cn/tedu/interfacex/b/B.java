package cn.tedu.interfacex.b;

import cn.tedu.interfacex.a.A;

public class B {
	
	public static void main(String[] args) {
		
		System.out.println(A.i);
		
	}

}
